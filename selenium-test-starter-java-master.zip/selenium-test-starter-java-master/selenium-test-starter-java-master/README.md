# Acceptance test Cucumber/Selenium/Java project

# To Run
Maven and Chromedriver required, defaults to run Chromedriver when ran

```
mvn test

```
