package com.something.something.steps;

import com.something.something.pages.Page;
import com.something.something.utils.Driver;
import io.cucumber.java8.En;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class StepDefs extends Driver implements En {
    private Page page = new Page();   // u can add pico container if u want to inject through constructor

    public StepDefs() {

        Given("I go to url (.*)$", (final String url) -> {
            page.getUrl(url);
        });
        And("^I click the Signin button$", () -> {
            driver.findElement(By.xpath("//*[@id=\"header-content\"]/nav/div[1]/div/div[1]/ul[2]/li[1]/a")).click();
        });
        Given("^I enter the user name as \"([^\"]*)\"$", (String userName) -> {
            WebElement uName= driver.findElement(By.id("user-identifier-input"));
            uName.sendKeys(userName);

        });

        Given("^I enter the password as \"([^\"]*)\"$", (String passsWord) -> {
            WebElement pWord= driver.findElement(By.id("password-input"));
            pWord.sendKeys(passsWord);

        });

        When("^I click login button$", () -> {
            WebElement lbuton= driver.findElement(By.id("submit-button"));
            lbuton.click();

        });

        Then("^I should see the login screen$", () -> {
            String actual_msg=driver.findElement(By.xpath("//*[@id=\"header-content\"]/div[2]/div/div/div/div")).getText();
            String expect="Welcome to the BBC";
            Assert.assertEquals(actual_msg, expect);

        });


    }

}
