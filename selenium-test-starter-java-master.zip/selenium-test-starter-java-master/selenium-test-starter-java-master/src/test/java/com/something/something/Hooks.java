package com.something.something;



import com.something.something.pages.Page;
import com.something.something.utils.Driver;
import io.cucumber.java.After;
import io.cucumber.java.Before;

import java.io.IOException;

public class Hooks extends Page {
    private Driver driverManager=new Driver();

    @Before
    public void setUp() throws IOException
    {
        driverManager.openBrowser();
    }

    @After
    public void tearDown()
    {
        driverManager.closeBrowser();
    }
}
