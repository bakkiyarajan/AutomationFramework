package com.something.something.pages;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import com.something.something.utils.Driver;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class Page extends Driver{


    public void getUrl(final String url) throws InterruptedException {
        driver.navigate().to(url);
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

    }

}





